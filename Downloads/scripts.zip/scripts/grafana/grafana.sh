#!/bin/bash

echo "-------------------------------------------------------------"
echo "Deploy Grafana On Kubernetes"
kubectl create -f grafana-datasource-config.yaml
echo "-------------------------------------------------------------"
kubectl create -f deployment.yaml
echo "-------------------------------------------------------------"
kubectl create -f service.yaml
echo "-------------------------------------------------------------"
echo "able to access the Grafana dashboard using any node IP on port 32000"
echo "-------------------------------------------------------------"
kubectl get pods -n monitoring