#!/bin/bash

echo "-------------------------------------------------------------"
echo "setting up alert manager"
kubectl create -f AlertManagerConfigmap.yaml
echo "-------------------------------------------------------------"
kubectl create -f AlertTemplateConfigMap.yaml
echo "-------------------------------------------------------------"
kubectl create -f Deployment.yaml
echo "-------------------------------------------------------------"
kubectl create -f Service.yaml
echo "-------------------------------------------------------------"
echo "access Alert Manager on Node Port 31000"
echo "-------------------------------------------------------------"
kubectl get pods -n monitoring
echo "-------------------------------------------------------------"
