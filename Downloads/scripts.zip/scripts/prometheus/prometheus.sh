#!/bin/bash

echo "-------------------------------------------------------------"
echo "prometheus setup..!"
kubectl create namespace monitoring
echo "-------------------------------------------------------------"
kubectl create -f clusterRole.yaml
echo "-------------------------------------------------------------"
kubectl create -f config-map.yaml
echo "-------------------------------------------------------------"
kubectl create  -f prometheus-deployment.yaml 
echo "-------------------------------------------------------------"
kubectl get deployments --namespace=monitoring
echo "-------------------------------------------------------------"
echo "Connecting To Prometheus Dashboard"
echo "Exposing Prometheus as a Service"
kubectl create -f prometheus-service.yaml --namespace=monitoring
echo "-------------------------------------------------------------"
echo "access the Prometheus dashboard using any of the Kubernetes node�s IP on port 30000"
echo "-------------------------------------------------------------"
kubectl get pod -n monitoring
echo "-------------------------------------------------------------"